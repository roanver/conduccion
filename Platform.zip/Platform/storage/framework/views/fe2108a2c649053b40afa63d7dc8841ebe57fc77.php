<?php echo $__env->make('welcome', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->startSection('content'); ?>

    <h1>You are currently not connected to any networks.</h1>

<?php $__env->stopSection(); ?><?php /**PATH C:\wamp64\www\conduccion\resources\views/vendor/laravelpwa/offline.blade.php ENDPATH**/ ?>